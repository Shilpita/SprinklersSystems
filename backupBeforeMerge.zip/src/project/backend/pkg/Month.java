package project.backend.pkg;

public enum Month {
             JAN
			,FEB
			,MAR
			,APR
			,MAY
			,JUN
			,JUL
			,AUG
			,SEP
			,OCT
			,NOV
			,DEC;
	
	private Month(){}
}
